console.log("Hello World!!")


const dyFm = (type, key, label,content=undefined, options=undefined) => {
    if (type == 'input') {
        return <p key={key}>{label} : <input  type="text"/></p>
    } else if (type == 'numberformat')  {
        return <p key={key}>{label} : <input  type="number"/></p>
    } else if (type == 'checkbox')  {
        return <p key={key}>{label} : <input  type="checkbox"/></p>
    } else if (type == 'button')  {
        return <p key={key}><input  type="submit" value={content}/></p>
    } else if (type == 'dropdown')  {
      return (
        <p key={key}>
          <label>{label} : </label>

          <select name={label} id="cars">
            {options.map((option) => {
              return <option key={option['value']} value={option['value']}>{option['text']}</option>
            })}
          </select>
        </p>
      )
  }
}

// dyFm(js['data-buildertype'], js['key'], js['label'],js['content'], js['data-elements'])

let jsonVAlues;

const getJson = (e) => {
  const inp = e.target.value;
  jsonVAlues = JSON.parse(inp).slice(1,);
  console.log(jsonVAlues)
  renderApp()
} 

const getFileData = (e) => {
    e.preventDefault()
    const data = e.target.elements.userFile;
    const reader = new FileReader()
    reader.onload = e.target.elements.userFile;
    const j = reader.readAsText(data.files[0]);
    console.log(j)
}

function handleFileSelect(event) {
    const reader = new FileReader()
    reader.onload = handleFileLoad;
    reader.readAsText(event.target.files[0])
  }
  


const appRoot = document.getElementById('app');

const renderApp = () => {
    const template = (
        <div>   
          <h3>Enter Your Json Values: </h3>
          <form id="userForm" onSubmit={getFileData}>
            <input type="file" accept=".json" name="userFile" />
            <button>Upload</button>
          </form>

          <textarea onChange={getJson} name="json" rows="20" cols="50"></textarea>
            <form>
                {
                  jsonVAlues && jsonVAlues.map((js) => {
                      return dyFm(js['data-buildertype'], js['key'], js['label'],js['content'], js['data-elements'])
                  })
                }
            </form>
        </div>
    )
    ReactDOM.render(template, appRoot);
    
}

renderApp();